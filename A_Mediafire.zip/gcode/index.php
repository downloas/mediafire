<?php
header("Location: https://www.g-code.co.id/");